
Background:

A simple Job Management Service must be developed. The goal of this system is to handle the
execution of multiple types of Jobs. The actions performed by these Jobs are not important; possible

examples of these Jobs could be performing a data-load into a DWH, performing indexing of some file-
based content or sending emails.

***********************************************************

API is developed using Spring Boot 4.Please below find URL for Job Management Service API.

http://localhost:8081/swagger-ui.html#/

1) This hav been implements file processing system(encryption of file). API accept four parameters as an argument.
Job priority
Job (File Path to list down file for encryption)
Scheduled/Non scheduled service
Job Type( Currently Api suppports FILE_PROCESSING)

Swagger API is used for representation logic.
