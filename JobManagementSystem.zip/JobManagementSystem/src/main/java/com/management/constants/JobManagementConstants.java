package com.management.constants;

public class JobManagementConstants {
	
	    public static final String KEY                       = "rajkupadhyay";
	    public static final String ALGORITHM                 = "Blowfish/CBC/PKCS5Padding";
	    public static final String ALGORITHM_NAME            = "Blowfish";
	    public static final String ASCII                     = "ASCII";
	    public static final String SUCCESS                   = "SUCCESS";
	    public static final String FAILED                    = "FAILED";
	    
	    private String jobStage;
	    private String jobPriority;
	    private String jobType;
	    private String errorMessage;
	    
		public JobManagementConstants()
	    {
	    	
	    }
	    
	    public JobManagementConstants(JobStates states, JobPriority priority, JobTypeSupport type)
	    {
	    	
	    }

	    public String getErrorMessage() {
			return errorMessage;
		}

		public void setErrorMessage(String errorMessage) {
			this.errorMessage = errorMessage;
		}
		
		public String getJobStage() {
			return jobStage;
		}
		public void setJobStage(String jobStage) {
			this.jobStage = jobStage;
		}
		public String getJobPriority() {
			return jobPriority;
		}
		public void setJobPriority(String jobPriority) {
			this.jobPriority = jobPriority;
		}
		public String getJobType() {
			return jobType;
		}
		public void setJobType(String jobType) {
			this.jobType = jobType;
		}
}
