package com.management.constants;

public enum JobPriority {
	
	HIGH,
	MEDIUM,
	LOW;

}
