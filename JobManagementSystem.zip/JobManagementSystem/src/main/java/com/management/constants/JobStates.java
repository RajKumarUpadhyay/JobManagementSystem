package com.management.constants;

public enum JobStates {
	QUEUED,
	RUNNING,
	SUCCESS,
	FAILED;
}
