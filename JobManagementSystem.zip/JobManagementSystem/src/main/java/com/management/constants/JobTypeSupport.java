package com.management.constants;

public enum JobTypeSupport {
      EMAIL_SERVICE,
      FILE_PROCESSING,
      DATA_PROCESSING;
}
