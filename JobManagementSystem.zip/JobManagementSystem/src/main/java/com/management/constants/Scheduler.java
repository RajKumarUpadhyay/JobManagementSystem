package com.management.constants;

public enum Scheduler {
	
	SCHEDULE_JOB,
	NON_SCHEDULE_JOB;

}
