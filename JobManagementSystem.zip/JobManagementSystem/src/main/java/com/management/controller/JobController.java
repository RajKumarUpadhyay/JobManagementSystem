/**
 * 
 */
package com.management.controller;

/**
 * @author Raj K Upadhyay
 *
 */
import java.io.IOException;

import javax.naming.ServiceUnavailableException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.JobStates;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.delegate.JobDelegate;
import com.management.exceptions.StandardCustomException;
import com.management.service.JobManagementValidationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/job_processor")
@Api(value="Job Processor Controller Api")
public class JobController {

	final static Logger logger = LoggerFactory.getLogger(JobController.class);
	JobManagementConstants response;
	@Autowired
	JobManagementValidationService jobManagementValidationService;

	@Autowired
	JobDelegate jobDelegate;

	@Autowired
	Environment environment;

	@RequestMapping(method = RequestMethod.POST)
	@ApiOperation(value="Accept Task_Url,Task_Priority,Task_Support_Type, Task_Scheduler as argument",notes="Please provide correct Task for processing data and use application properties for change configuration.")
	public ResponseEntity<JobManagementConstants> jobManagementService(@RequestParam("Task_Url") String taskUrl,
			@RequestParam("Task_Priority") JobPriority jobPriority,
			@RequestParam("Task_Support_Type") JobTypeSupport jobTypeSupport,
			@RequestParam("Task_Scheduler") Scheduler taskScheduler) throws IOException 
	{

		logger.info("Job Management Service Is Invoked with listed parameters "+taskUrl +
														"jobPriority "+jobPriority+
														"jobTypeSupport "+jobTypeSupport+
														"taskScheduler "+taskScheduler);
		try
		{
			if(jobManagementValidationService.validateJobParametes(jobPriority, taskScheduler, jobTypeSupport, taskUrl))
			{
				response = jobDelegate.getJobManagementFacade(jobPriority, taskScheduler, jobTypeSupport, taskUrl, environment);
			}
			else
			{
				response = new JobManagementConstants();
				response.setErrorMessage("Validation failed. Verify input details.");
				response.setJobStage(JobStates.FAILED.toString());
				response.setJobPriority(jobPriority.toString());
				response.setJobType(jobTypeSupport.toString());
				throw new StandardCustomException("Validation failed. Verify input details.");
			}
		}
		catch(StandardCustomException  customException)
		{
			response = new JobManagementConstants();
			response.setErrorMessage(customException.getMessage());
			response.setJobStage(JobStates.FAILED.toString());
			response.setJobPriority(jobPriority.toString());
			response.setJobType(jobTypeSupport.toString());
			return new ResponseEntity<JobManagementConstants>(response, HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<JobManagementConstants>(response, HttpStatus.OK);
	}
}
