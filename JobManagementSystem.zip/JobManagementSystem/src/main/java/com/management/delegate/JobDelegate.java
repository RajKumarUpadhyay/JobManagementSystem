package com.management.delegate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.facade.JobManagementFacadeService;

@Component
public class JobDelegate {
	
	final static Logger logger = LoggerFactory.getLogger(JobDelegate.class);
	
	@Autowired
	JobManagementFacadeService jobManagementFacadeService;
	
	public JobManagementConstants getJobManagementFacade(JobPriority jobPriority, Scheduler scheduler, JobTypeSupport jobTypeSupport,
			String url,Environment environment)
	{
		return jobManagementFacadeService.getJobManagementService(jobPriority, scheduler, jobTypeSupport, url, environment);
	}
}
