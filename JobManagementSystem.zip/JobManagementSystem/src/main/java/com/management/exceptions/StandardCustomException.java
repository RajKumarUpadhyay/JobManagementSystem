package com.management.exceptions;

public class StandardCustomException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3660633925662141195L;

	public StandardCustomException(String exceptionMessage)
	{
		super(exceptionMessage);
	}
}
