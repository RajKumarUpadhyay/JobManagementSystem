package com.management.facade;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.exceptions.StandardCustomException;
import com.management.service.JobManagementService;

@Component
public class JobManagementFacade implements JobManagementFacadeService {
	
	final static Logger logger = LoggerFactory.getLogger(JobManagementFacade.class);

	@Autowired
	JobManagementService jobManagementService;
	
	@Override
	public JobManagementConstants getJobManagementService(JobPriority jobPriority, Scheduler scheduler,
			JobTypeSupport jobTypeSupport, String path,Environment environment) throws StandardCustomException {
		
		if(JobTypeSupport.FILE_PROCESSING.equals(jobTypeSupport))
		{
			return jobManagementService.fileProcessor(path, scheduler, jobPriority, environment);
		}
		else if(JobTypeSupport.EMAIL_SERVICE.equals(jobTypeSupport))
		{
			//TO DO: Need to add handler for process mail
			throw new StandardCustomException("Email Service doesn't support. Contact to administrator.");
		}
		else
		{
			//TO DO: Need to add handler for Other services.
			throw new StandardCustomException("Unknown Service. Contact to administrator.");
		}
	}
}
