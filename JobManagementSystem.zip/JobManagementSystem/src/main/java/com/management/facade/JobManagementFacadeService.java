package com.management.facade;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.exceptions.StandardCustomException;

@Service
public interface JobManagementFacadeService {
	
	public JobManagementConstants getJobManagementService(JobPriority jobPriority, Scheduler scheduler, JobTypeSupport jobTypeSupport,String url,Environment environment) throws StandardCustomException;

}
