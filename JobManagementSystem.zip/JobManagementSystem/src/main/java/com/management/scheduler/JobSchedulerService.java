package com.management.scheduler;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.exceptions.StandardCustomException;

@Service
public interface JobSchedulerService {
	public JobManagementConstants executeJob(String path, JobPriority jobPriority,Environment environment) throws StandardCustomException;
	public JobManagementConstants executeScheduleJob(String path, JobPriority jobPriority,Environment environment) throws StandardCustomException;

}
