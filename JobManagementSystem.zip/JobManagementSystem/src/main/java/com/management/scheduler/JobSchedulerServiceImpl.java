package com.management.scheduler;

import java.io.File;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.JobStates;
import com.management.constants.JobTypeSupport;
import com.management.exceptions.StandardCustomException;
import com.management.util.JobHandlerServiceUtil;

@Component
public class JobSchedulerServiceImpl implements JobSchedulerService, ThreadFactory {

	final static Logger logger = LoggerFactory.getLogger(JobSchedulerServiceImpl.class);

	private ScheduledThreadPoolExecutor shceduledThreadPool;
	protected ExecutorService executor = null;
	JobManagementConstants constants;
	JobHandlerServiceUtil jobHandlerServiceUtil = new JobHandlerServiceUtil();

	@Override
	public JobManagementConstants executeJob(String path, JobPriority jobPriority,Environment environment) throws StandardCustomException {
		
		constants= new JobManagementConstants();
		List<File> listOfFiles = jobHandlerServiceUtil.getFileList(path,constants);
		constants.setJobPriority(jobPriority.toString());
		constants.setJobStage(JobStates.QUEUED.toString());
		constants.setJobType(JobTypeSupport.FILE_PROCESSING.toString());
		
		try
		{
			executor = Executors.newFixedThreadPool(listOfFiles.size() , this);
			for (File filePath : listOfFiles)
			{
				Callable<JobManagementConstants> theCallable = new Callable<JobManagementConstants>()
				{
					@Override
					public JobManagementConstants call() throws Exception
					{
						constants.setJobStage(JobStates.RUNNING.toString());
						return jobHandlerServiceUtil.encryptFile(filePath , constants);
					}
				};
				executor.submit(theCallable).get();
			}
		}
		catch (InterruptedException  | RejectedExecutionException | ExecutionException e)
		{
			logger.info("Running job is interrupted. Called gracefull shutdown.");
			constants.setErrorMessage(e.getMessage());
			constants.setJobStage(JobStates.FAILED.toString());;
		}
		return constants;
	}

	@Override
	public JobManagementConstants executeScheduleJob(String path, JobPriority jobPriority,Environment environment) throws StandardCustomException {

		constants= new JobManagementConstants();
		List<File> listOfFiles = jobHandlerServiceUtil.getFileList(path,constants);
		constants.setJobPriority(jobPriority.toString());
		constants.setJobStage(JobStates.QUEUED.toString());
		constants.setJobType(JobTypeSupport.FILE_PROCESSING.toString());
		return processFiles(listOfFiles, environment);
	}

	public final JobManagementConstants processFiles(List<File> listOfFiles,Environment environment) throws StandardCustomException
	{
		int thCount = listOfFiles.isEmpty() ? 0 :listOfFiles.size();
		long timeToStart =  Long.parseLong(environment.getProperty("THREAD_CALLBACK_TIME").trim());

		try
		{
			shceduledThreadPool = (ScheduledThreadPoolExecutor) Executors.newScheduledThreadPool(thCount);
			shceduledThreadPool.setRemoveOnCancelPolicy(true);

			listOfFiles.forEach(filePath->{
				Callable<JobManagementConstants> theCallable = new  Callable<JobManagementConstants>()
				{
					@Override
					public JobManagementConstants call() throws Exception {
						constants.setJobStage(JobStates.RUNNING.toString());
						return jobHandlerServiceUtil.encryptFile(filePath,constants);
					}
				};
				shceduledThreadPool.schedule(theCallable, timeToStart,  TimeUnit.MILLISECONDS);
			});
		}
		catch(RejectedExecutionException ex)
		{
			logger.info("Runing job is interuppted. Prepare for shutting down pool."+ ex.getMessage());
			constants.setErrorMessage(ex.getMessage());
			constants.setJobStage(JobStates.FAILED.toString());;
		}
		if(!Objects.nonNull(constants.getErrorMessage()))
		{
			constants.setErrorMessage("");
			constants.setJobStage(JobStates.SUCCESS.toString());
		}
		return constants;
	}

	@PreDestroy
	public void destroy()
	{
		if(Objects.nonNull(shceduledThreadPool))
		{
			awaitTerminationAfterShutdown(shceduledThreadPool);
		}
	}

	/**
	 * Method awaitTerminationAfterShutdown will invoked when user want to<br>
	 * destroy thread pool. It will prevent running thread to complete executing task<br>
	 * and shutdown pool gracefully.
	 * 
	 * @param parExecutor
	 */
	public final void awaitTerminationAfterShutdown(ExecutorService parExecutor)
	{
		try
		{
			if (!parExecutor.isShutdown())
			{
				parExecutor.shutdown();
				parExecutor.awaitTermination(2000L, TimeUnit.MILLISECONDS);
			}
		}
		catch (Exception ex)
		{
			logger.info("Trying to stop new job submittion into the thread pool");
			parExecutor.shutdownNow();
			Thread.currentThread().interrupt();
			logger.info("Runing Job is completed. Component shutdown is invioked.");
		}
	}

	@Override
	public Thread newThread(Runnable r) {
		 Thread t = new Thread(r);
	        t.setDaemon(true);
	        t.setName("FileProcessor");
	        t.setPriority(Thread.MIN_PRIORITY);
	        return t;
	}

}
