package com.management.service;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.Scheduler;
import com.management.exceptions.StandardCustomException;

@Service
public interface JobManagementService {
	
	public JobManagementConstants sendEmail() throws StandardCustomException;
	public JobManagementConstants fileProcessor(String path, Scheduler scheduler, JobPriority jobPriority,Environment environment) throws StandardCustomException;
	public JobManagementConstants dataProcessor() throws StandardCustomException;

}
