package com.management.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.Scheduler;
import com.management.exceptions.StandardCustomException;
import com.management.scheduler.JobSchedulerService;

@Component
public class JobManagementServiceImpl implements JobManagementService {
	
	final static Logger logger = LoggerFactory.getLogger(JobManagementServiceImpl.class);

	@Autowired
	JobSchedulerService jobSchedulerService;
	
	@Override
	public JobManagementConstants sendEmail() throws StandardCustomException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JobManagementConstants fileProcessor(String path, Scheduler scheduler, JobPriority jobPriority,Environment environment) throws StandardCustomException {
		
		if(Scheduler.SCHEDULE_JOB.equals(scheduler))
		{
			return jobSchedulerService.executeScheduleJob(path,jobPriority, environment);
		}
		else
		{
			return jobSchedulerService.executeJob(path,jobPriority, environment);
		}
	}

	@Override
	public JobManagementConstants dataProcessor() throws StandardCustomException {
		// TODO Auto-generated method stub
		return null;
	}


}
