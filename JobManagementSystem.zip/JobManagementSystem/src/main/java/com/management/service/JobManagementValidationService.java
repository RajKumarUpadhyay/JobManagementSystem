package com.management.service;

import org.springframework.stereotype.Service;

import com.management.constants.JobPriority;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.exceptions.StandardCustomException;

@Service
public interface JobManagementValidationService {
	/**
	 * This method will validate input parameters of Task. IT can be extended futher as per need.
	 * @param jobPriority
	 * @param scheduler
	 * @param jobTypeSupport
	 * @param url
	 * @return
	 * @throws StandardCustomException
	 */
     public boolean validateJobParametes(JobPriority jobPriority, Scheduler scheduler, JobTypeSupport jobTypeSupport,String url) throws StandardCustomException; 
}
