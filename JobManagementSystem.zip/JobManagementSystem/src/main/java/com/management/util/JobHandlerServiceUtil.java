package com.management.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobStates;
import com.management.exceptions.StandardCustomException;

public class JobHandlerServiceUtil implements ThreadFactory{

	final static Logger logger = LoggerFactory.getLogger(JobHandlerServiceUtil.class);

	protected ExecutorService executor = null;
	private static final  byte[] RAWIV = {60,62,64,66,68,70,72,74};

	public JobHandlerServiceUtil()
	{

	}

	/**
	 *Method getFileList used to list the file file on<br>
	 *basis of given file path.
	 *
	 *@return list of files.
	 * */
	public final List<File> getFileList(String filePath, JobManagementConstants constants) throws StandardCustomException
	{
		List<File> results = new ArrayList<File>();
		try
		{
			File[] files = new File(filePath).listFiles();

			for (File file : files) {
				if (file.isFile()) {
					results.add(file);
				}
			}
		}
		catch(Exception exception)
		{
			constants.setErrorMessage("Path is invalid or file doesn't exist::"+exception.getMessage());
		}
		return results;
	}

	/**
	 * Method encryptFile will used to encrypt batch file. This method<br>
	 * provide implementation of Blowfish algorithm using Crypto java library.This<br>
	 * method will encrypt batch file.
	 * 
	 * @param filePath
	 * @param constants
	 * @return
	 */
	public final JobManagementConstants encryptFile(File filePath,JobManagementConstants constants)
	{
		Cipher cipherOut = initilizeBlowfish();

		try
		{
			FileReader fileReader = new FileReader(filePath);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			FileWriter theFileWriter = new FileWriter(filePath.getAbsoluteFile());
			String line = null;

			while((line = bufferedReader.readLine()) != null)
			{
				byte[] encryptedData = cipherOut.doFinal(line.getBytes());
				theFileWriter.write(Base64.getEncoder().encodeToString(encryptedData));
				theFileWriter.write(System.lineSeparator());
			}
			closeOpenStream(bufferedReader,fileReader ,theFileWriter);
		}
		catch (IOException |NullPointerException | StandardCustomException | IllegalBlockSizeException | BadPaddingException ex)
		{
			logger.warn("Failed to rename batch file ");
			constants.setErrorMessage(ex.getMessage());
			constants.setJobStage(JobStates.FAILED.toString());;
			return constants;
		}
		constants.setJobStage(JobStates.SUCCESS.toString());
		return constants;
	}

	/**
	 * This method initialized Blowfish algorithm using CBC<br>
	 * mode. Method used Blowfish/CBC/PKCS5Padding algorithm for <br>
	 * creating instance of Cipher.
	 * 
	 * @return Cipher object of Cipher.
	 */
	private final Cipher initilizeBlowfish()
	{
		byte[] keyBytes = null;
		Cipher cipherOut = null;

		try
		{
			keyBytes = JobManagementConstants.KEY.getBytes(JobManagementConstants.ASCII);
			Key key = new SecretKeySpec(keyBytes, JobManagementConstants.ALGORITHM_NAME);
			IvParameterSpec iv = new IvParameterSpec(RAWIV);
			cipherOut = Cipher.getInstance(JobManagementConstants.ALGORITHM);
			cipherOut.init(Cipher.ENCRYPT_MODE, key, iv);
		}
		catch (UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException ex)
		{
			logger.info("Blowfish initilization failed");
		}
		return cipherOut;
	}

	/**
	 * This method closed all open stream of reader and writer of <br>
	 * batch file encryption.
	 * 
	 * @param bufferedReader
	 * @param fileReader
	 * @param outputStream
	 */
	private void closeOpenStream(BufferedReader bufferedReader, FileReader fileReader, FileWriter theFileWriter)
	{
		if(Objects.nonNull(bufferedReader))
		{
			try
			{
				bufferedReader.close();
			}
			catch (IOException e)
			{
				logger.info("BufferedReader stream not closed successfully");
			}
		}
		if(Objects.nonNull(fileReader))
		{
			try
			{
				fileReader.close();
			}
			catch (IOException e)
			{
				logger.info("FileReader stream not closed successfully");
			}
		}

		if(Objects.nonNull(theFileWriter))
		{
			try
			{
				theFileWriter.close();
			}
			catch (IOException e)
			{
				logger.info("OutputStream stream not closed successfully");
			}
		}
	}

	@Override
	public Thread newThread(Runnable parR)
	{
		Thread t = new Thread(parR);
		t.setDaemon(true);
		t.setName("BatchFileEncryptUtil");
		t.setPriority(Thread.MIN_PRIORITY);
		return t;
	}
}
