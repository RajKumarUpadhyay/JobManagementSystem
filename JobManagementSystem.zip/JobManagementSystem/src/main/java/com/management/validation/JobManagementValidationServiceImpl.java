package com.management.validation;

import java.nio.file.InvalidPathException;
import java.nio.file.Paths;
import java.util.Objects;

import org.springframework.stereotype.Component;

import com.management.constants.JobPriority;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.exceptions.StandardCustomException;
import com.management.service.JobManagementValidationService;

@Component
public class JobManagementValidationServiceImpl implements JobManagementValidationService
{

	@Override
	public boolean validateJobParametes(JobPriority jobPriority, Scheduler scheduler, JobTypeSupport jobTypeSupport,
			String url) throws StandardCustomException {

		if(Objects.nonNull(jobPriority) && Objects.nonNull(scheduler) && Objects.nonNull(jobTypeSupport))
		{
			if(Objects.nonNull(jobTypeSupport))
			{
				isValidPath(url);
			}
		}
		return true;
	}

	public static boolean isValidPath(String path) {
		try {
			Paths.get(path);
		} catch (InvalidPathException | NullPointerException ex) {
			throw new StandardCustomException("File location is not valid");
		}
		return true;
	}

}
