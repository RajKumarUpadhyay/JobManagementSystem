package com.management;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.management.constants.JobManagementConstants;
import com.management.constants.JobPriority;
import com.management.constants.JobTypeSupport;
import com.management.constants.Scheduler;
import com.management.delegate.JobDelegate;
import com.management.exceptions.StandardCustomException;
import com.management.util.JobHandlerServiceUtil;
import com.management.validation.JobManagementValidationServiceImpl;

public class JobManagementSystemApplicationTests{
	
	JobManagementValidationServiceImpl jobManagementValidationServiceImpl;
	JobHandlerServiceUtil jobHandlerServiceUtil;
	JobManagementConstants constants;
	JobDelegate jobDelegate;
	
	@Before
    public void setUp() throws StandardCustomException
    {
		jobManagementValidationServiceImpl = new JobManagementValidationServiceImpl();
		jobHandlerServiceUtil = new JobHandlerServiceUtil();
		jobDelegate = new JobDelegate();
		constants=  new JobManagementConstants();
    }

    @Test
    public void testValidateInputParameters() throws StandardCustomException
    {
    	org.junit.Assert.assertTrue(jobManagementValidationServiceImpl.validateJobParametes(JobPriority.HIGH, Scheduler.SCHEDULE_JOB, JobTypeSupport.FILE_PROCESSING,JobManagementTestHelper.PATH));
    }
    
    @Test
    public void testFileList() throws StandardCustomException
    {
    	org.junit.Assert.assertNotNull(jobHandlerServiceUtil.getFileList(JobManagementTestHelper.PATH, constants));
    }
    
    @After
    public void tearDown()
    {
    	jobManagementValidationServiceImpl = null;
    	jobHandlerServiceUtil= null;
    	constants = null;
    	jobDelegate = null;
    }
}

