package com.management;

public class JobManagementTestHelper {
	
	public static final String PATH = "C:\\Users\\RAJKUPADHYAY\\Desktop\\Tax\\";

}
